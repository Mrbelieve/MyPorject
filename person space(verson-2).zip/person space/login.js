$(document).ready(function () {
    //主页默认登录框，隐藏注册输入框
    for(var i = 3;i < 7;i ++){
        $(".textbox").eq(i).hide();
    }
    //悬停特效
    $(".container").mouseover(function () {
        $(".ring").css({
            "border":"#00FF00 1px solid",
            "color":"#00FF00"
        });
    })
    $(".container").mouseout(function () {
        $(".ring").css({
            "border":"none",
            "color":"white"
        });
    })

    var identify = 0;                              //登录和注册标识：0为登录操作，1为注册操作
    //注册
    $("#sign").click(function () {
        //输入框切换效果
        $(".textbox").eq(1).hide();
        $(".textbox").eq(2).hide();
        for(var i = 3;i < 7;i ++){
            $(".textbox").eq(i).show();
        }
        //旋转特效
        $(".ring").css({
            "transform":"rotateY(360deg)",
            "transition":"transform 2s"
        });
        $(".container").css({
            "transform":"rotateY(360deg)",
            "transition":"transform 2s"
        })

        identify = 1;                                                //用户输入合法性判定
        var tel = /^1[3456789]\d{9}$/;                            //电话号码正则
        var E = /^([\w\.\-]+)\@(\w+)(\.([\w^\_]+)){1,2}$/;       //邮箱正则
        var pw = /^\d{6}$/;                                        //密码的正则
        var userName = $("#newUser").val();                         //获取用户名
        var email = $("#email").val();                              //获取用户邮箱
        var passWord = $("#newPassword").val();                     //获取密码
        var confirm_password = $("#confirm_password").val();        //确认密码
        var date = new Date();
        var sign_date = date.getFullYear() + "-" + date.getMonth() + "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
        if(tel.test(userName)&&E.test(email)&&pw.test(passWord)){   //用户名合法，邮箱合法，密码合法
            if(confirm_password == passWord){               //确认密码一致
                $.ajax({
                    type:"get",
                    url: "php/check.php",
                    data: "name="+userName+"&email="+email+"&password="+passWord+"&identify="+identify+"&sign_date="+sign_date,
                    success:function (response) {
                        alert(response);
                        window.location.reload();
                    },
                    error:function (response) {
                        alert("发生错误！"+response);
                    }
                })
            }else {
                alert("确认密码与密码不一致，请重新输入！")
                $("#newPassword").val("");
                $("#confirm_password").val("");
            }
        }else {
            alert("请输入11位电话号码+个人邮箱+6位密码进行注册！");
            clear();
        }
    })
    //登录
    $("#login").click(function () {
        //输入框切换效果
        for(var i = 3;i < 7;i ++){
            $(".textbox").eq(i).hide();
        }
        $(".textbox").eq(1).show();
        $(".textbox").eq(2).show();

        identify = 0;                                         //用户输入合法性判定
        var tel = /^1[3456789]\d{9}$/;                     //电话号码正则
        var pw = /^\d{6}$/;                                 //密码的正则
        var userName = $("#Username").val();                 //获取用户的输入
        var passWord = $("#password").val();                 //获取密码
        if(tel.test(userName) && pw.test(passWord)){          //账号和密码合法
            $.ajax({
                type:"get",
                url: "php/check.php",
                data: "name="+userName+"&password="+passWord+"&identify="+identify,
                success:function (response) {
                    if(response == 1){
                        location.href='personalPage.html?'+'name=' + encodeURI(userName);
                        // window.open("personalPage.html");
                    }else if(response == 2) {
                        alert("密码错误！");
                    }
                    else if(response == 3){
                        alert("账号不存在！")
                    }
                },
                error:function (response) {
                    alert("发生错误！" + response)
                }
            })
        }else {
            alert("请输入11位手机号码+6位数密码进行登陆！");
            clear();
        }
    })

    //输入框信息清空函数
    function clear(){
        $("#Username").val("");
        $("#password").val("");
        $("#newUser").val("");
        $("#email").val("");
        $("#newPassword").val("");
    }
})