<?php
/**
 * Created by PhpStorm.
 * User: I believe
 * Date: 2019/8/7
 * Time: 15:28
 */
//header("Content-Length:504000");
    $name = $_POST["name"];
    $identify = $_POST["identify"];
$connect = mysqli_connect("localhost:3306","root","");
if($connect){
    mysqli_select_db($connect,"test");
    $connect->query("set names utf8");//设置数据库查询的编码方式，避免中文乱码
    if($identify == 4){
        //修改头像
        $img = $_POST["img"];
        $query = mysqli_query($connect,"UPDATE user SET img='$img' WHERE name=".$name);
        if($query){
            $myfile = fopen("C:/Users/I believe/Desktop/".$name.".txt","w") or die("Unable to open file!");
            fwrite($myfile,$img);
            fclose($myfile);
            echo "头像上传数据库成功";
        }else{
            echo "false";
        }
    }else if($identify == 5){
        //头像加载
        $query = mysqli_query($connect,"SELECT img FROM `user` WHERE name=".$name);
        if($query){
            $myfile = fopen("C:/Users/I believe/Desktop/".$name.".txt","r") or die("Unable to open file!");
            while (!feof($myfile)){
                echo fgetc($myfile);
            }
            fclose($myfile);
        }else{
            echo "false";
        }
    }else if($identify == 6){
        //新建笔记
        $content = $_POST["content"];
        $groups = $_POST["lable"];
        $date = $_POST["date"];
        $imgstring = $_POST["imgstring"];
        $query = mysqli_query($connect,"INSERT INTO `user_data` (`id`, `name`, `groups`, `content`,`content_img`, `create_date`) VALUES (NULL,$name, '$groups', '$content','$imgstring', '$date')");
        if($query){
            $file = substr($name,7,5).$date;
            $result = str_replace(array(' ',':'),array('',''),$file);//当名字前去除特殊字符
            echo "新建成功";
//            $myfile = fopen("C:\Users\I believe\Desktop\\".$file.".txt","w");
            $myfile = fopen("C:\Users\I believe\Desktop\\".$result.".txt","w");
            fwrite($myfile,$imgstring);
            fclose($myfile);
            }else{
                echo "false";
            }
    }
    else if($identify == 7){
        $content = $_POST["content"];
        $query = mysqli_query($connect,"DELETE FROM `user_data` WHERE `name`='$name' AND `content`='$content'");
        if($query){
            echo "删除成功！";
        }else{
            echo "false";
        }
    }
    else if($identify == 8){
        //编辑记录
        $olddate = $_POST["olddate"];
        $content = $_POST["content"];
        $newdate = $_POST["newdate"];
        $newgroups = $_POST["groups"];
        $query = mysqli_query($connect,"UPDATE `user_data` SET `content`='$content',`create_date`='$newdate',`groups`='$newgroups' WHERE `user_data`.`name`=$name AND `user_data`.`create_date`='$olddate'");
        if($query){
            echo $newgroups;
        }else{
            echo "false";
        }
    }
    else if($identify == 9){
        //        查询所有笔记
        $query = mysqli_query($connect,"SELECT groups,content,content_img,create_date FROM user_data WHERE name=$name ORDER BY create_date DESC");
        if($query){
            $row = mysqli_num_rows($query);
            for($i = 0;$i < $row;$i++){
                $result = mysqli_fetch_assoc($query);
                $content_img = $result["content_img"];
//                if($content_img){
//                    $content_img = "";
//                    $fname = substr($name,7,5).$result["create_date"];
//                    $filename = str_replace(array(' ',':'),array('',''),$fname);
//                    $myfile = fopen("C:\Users\I believe\Desktop\\".$filename.".txt","r");
//                    while (!feof($myfile)){
//                        $content_img = $content_img + fgetc($myfile);
//                    }
//                    fclose($myfile);
//                }
                $string_result = $result["groups"]."|??|".$result["content"]."|??|".$result["create_date"];
                echo $string_result."***;][()";
            }
        }else{
            echo "false";
        }
    }
}else{
    echo "数据库连接失败！";
}
?>