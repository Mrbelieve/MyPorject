<?php
/**
 * Created by PhpStorm.
 * User: I believe
 * Date: 2019/8/15
 * Time: 15:31
 */
$name = $_POST["name"];
$identify = $_POST["identify"];
$connect = mysqli_connect("localhost:3306","root","");
if($connect){
    mysqli_select_db($connect,"test");
    if($identify == 0){
        $imgstring = $_POST["imgstring"];
        $content = $_POST["content"];
        $query = "UPDATE user_data SET content_img='$imgstring' WHERE content='$content'";
        if($query){
            echo "图片上传数据库成功！";
            $myfile = fopen("C:\Users\I believe\Desktop\\".$name.".txt","w");
            fwrite($myfile,$imgstring);
            fclose($myfile);
        }else{
            echo "false";
        }
    }else if($identify == 1){
        $query = "SELECT img FROM test WHERE name=".$name;
        if($query){
            $myfile = fopen("C:\Users\I believe\Desktop\\".$name.".txt","r") or die("fail to onload image");
            while (!feof($myfile)){
                echo fgetc($myfile);
            }
//            $result = fread($myfile,filesize("C:\Users\I believe\Desktop\\".$name.".txt"));
//            fclose($myfile);
        }else{
            echo "false";
        }

    }
}else{
    echo "数据库连接失败！；";
}
?>