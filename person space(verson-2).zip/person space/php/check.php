<?php
/**
 * Created by PhpStorm.
 * User: I believe
 * Date: 2019/7/30
 * Time: 20:56
 */
$name = $_GET["name"];
$identify = $_GET["identify"];
$password = $_GET["password"];
$connect = mysqli_connect("localhost:3306","root","");
if($connect){
    $connectDb = mysqli_select_db($connect,"test");
    if($identify){
        //用户注册
        $email = $_GET["email"];
        $sign_date = $_GET["sign_date"];
        $string1 = "INSERT INTO `user` ( `name`, `email`, `password`,`sign_date`) VALUES ('$name', '$email', '$password','$sign_date')";
        $string2 = "INSERT INTO `groups` (`name`,`groups_name`) VALUES ('$name','默认')";
        $query1 = mysqli_query($connect,$string1);//数据库插入操作语句
        $query2 = mysqli_query($connect,$string2);
        if($query1 && $query2){
            echo "注册成功！";
        }else{
            echo "该账号已注册！";
        }
    }else{
        //用户登录
        $query = mysqli_query($connect,"SELECT password FROM user WHERE name=".$name);//数据库查询操作语句
        $count=mysqli_num_rows($query);
         //   用户存在
        if ($count){
            $result = mysqli_fetch_assoc($query);
            if($result["password"] == $password){
                echo "1";
            }else{
                echo "2";
            }
           // $jsonresult = json_encode($result);
           // echo $jsonresult;
        }else{
            echo "3";
        }
    }
}else{
    echo "数据库连接失败！";
}
?>