$(document).ready(function(){
    //个人中心
    $( function() {
        $( "#tabs" ).tabs();
    } );
    $("#person").click(function () {
        $("#tabs").fadeIn(500);
    })
    $(".exist").click(function () {
        $("#tabs").fadeOut(500);
    })

    //按条件筛选
    $( function() {
        $( "#speed" ).selectmenu();
    } );

    //新建对话框
    $("#newlable").click(function () {
        $(".newnote").slideDown(1000);
    })
    //图片内容上传

    var imgstring = "";//存储base64码
    var imgnum = 0;//记录图片张数
    $(document).on("change","#upload_button",function () {
        var obj = document.getElementById("upload_button");
        var reader = new FileReader();
        var file = obj.files[0];
        reader.onload = function () {
            $("#img_container").prepend("<img class='imgbox' src=" + reader.result + " \"></img>");
            imgstring = imgstring + "!          !" + reader.result;
            imgnum = imgnum + 1;
        }
        reader.readAsDataURL(file);
    })
    $(document).on("click","#upload_box",function () {
        $("#upload_button").trigger("click")
    })

    $(".newnote_close").click(function () {
        //关闭新建对话框
        $(".newnote").slideUp(1000);
    })
    $(".newnote li").eq(2).on("click",function () {
        //清空内容
        $(".newnote textarea").val("");
    })

    $(".newnote li").eq(1).on("click",function () {
        if(imgnum > 6){
            imgstring = "";
            return "最多只能上传6张图片，请重新选择！";
        }
        //保存操作
        var date = new Date();
        var datestring = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + date.getDate()+"  "+date.getHours()+":"+date.getMinutes()+":"+date.getSeconds();//日期
        var content = $(".newnote textarea").val();//内容
        var lable_name = $(".newnote option:selected").text();//获取当前标签选定值
        var name = $("#username").text();
        var identify = 6;
        if(content){
            $.ajax({
                type:"post",
                url:"php/test.php",
                data:{
                  name:name,
                  identify:identify,
                  content:content,
                  lable:lable_name,
                  date:datestring,
                  imgstring:imgstring,
                },
                success:function (response) {
                    if(response == "false"){
                        alert("新建失败！");
                    }else {
                        var base64_code = imgstring.split("!          !");
                        var img = "";
                        for(var i = 1;i < base64_code.length;i ++){
                            img = img + "<img class='imgbox' src=\"" + base64_code[i] + "\"></img>";
                            $("#img_container .imgbox").remove();
                        }
                        $(".newnote").slideUp(500);
                        if(imgstring == ""){
                            $(".content").prepend("<div class=\"note background\"><pre class=\"note note_content\">"+content+" </pre><div class=\"note note_edit\">"+
                                " <ul> <li>"+lable_name+"</select></li> <li class=\"text edit_note\"><i class=\"fas fa-edit\"></i>  编辑</li> <li class=\"text delete_note\">" +
                                "<i class=\"fas fa-trash-alt\"></i>  删除</li> <li>            </li> <li>"+datestring+"</li> </ul> </div> </div><br>");

                        }else {
                            $(".content").prepend("<div class=\"note background\"><pre class=\"note note_content\">"+content+" </pre><div class='note imgcontain'>" + img + "</div><div class=\"note note_edit\">"+
                                " <ul> <li>"+lable_name+"</select></li> <li class=\"text edit_note\"><i class=\"fas fa-edit\"></i>  编辑</li> <li class=\"text delete_note\">" +
                                "<i class=\"fas fa-trash-alt\"></i>  删除</li> <li>            </li> <li>"+datestring+"</li> </ul> </div> </div><br>");
                        }
                        $(".newnote textarea").val("");//清空内容
                        $(".newnote option:selected").text("默认");//回归默认标签选定值
                    }
                },
                error:function (response) {
                    alert("（新建操作）发生错误！"+response);
                }
            })
        }else {
            alert("内容不能为空！")
        }
    })

    //编辑记录
    $(document).on("click",".edit_note",function () {
        var new_content = $(this).parent().parent().prev();     //定位到原内容文本框
        var date = $(this).next().next().next().text();         //旧日期
        var olddate = date;
        var text = new_content.text();                           //原内容
        $(".editnote textarea").val(text);                       //原内容放到编辑框
        var lable = $(this).prev();
        // $(".editnote option:selected").text();
            $(".editnote").slideDown(500,function () {
            $(".editnote li").eq(1).click(function () {
                //保存
                var date = new Date();
                var datestring = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + date.getDate()+"  "+date.getHours()+":"+date.getMinutes()+":"+date.getSeconds();//日期
                var name = $("#username").text();
                var newcontent = $(".editnote textarea").val();             //新内容
                var newgroups = $(".editnote option:selected").text();
                var identify = 8;
                if(newcontent){
                    $.ajax({
                        type:"post",
                        url:"php/test.php",
                        data:"name="+name+"&identify="+identify+"&olddate="+olddate+"&newdate="+datestring+"&content="+newcontent+"&groups="+newgroups,
                        success:function (response) {
                            if(response == "false"){
                                alert("保存失败！");
                            }else {
                                new_content.text(newcontent);//更新原文本内容
                                lable.text(newgroups);
                                $(".editnote").slideUp(500);
                            }
                        },
                        error:function (response) {
                            alert("保存操作发生错误！"+response);
                        }
                    })
                }else {
                    alert("内容不能为空！")
                }
            })

            $(".editnote_close").click(function () {
                //关闭
                $(".editnote").slideUp(500);
            })

            $(".editnote li").eq(2).click(function () {
                //清空
                $(".editnote textarea").val("");
            })
        });
    })

    //    删除记录
    $(document).on("click",".delete_note",function () {
        var br = $(this).parent().parent().parent().next();
        var content = $(this).parent().parent().prev();
        var name = $("#username").text();
        var identify = 7;
        // alert(content.text()+name);
        $.ajax({
            type:"post",
            url:"php/test.php",
            data:"name="+name+"&identify="+identify+"&content="+content.text(),
            success:function (response) {
                if(response == "false"){
                    alert("删除记录失败！");
                }else {
                    br.remove();
                    console.log(response);
                }
            },
            error:function (response) {
                alert("删除操作发生错误！"+response);
            }
        })
        $(this).parent().parent().parent().hide("slide",500);
    })

    //    标签管理
    $("#groupsmanage").click(function () {
        $(".group_manage").slideDown(1000);
    })
    $(".groupedit_close li").click(function () {
        $(".group_manage").slideUp(1000)
    })

    //    编辑标签名字
    $(document).on("click",".edit_group",function () {
        $(this).prev().children().removeAttr("disabled").focus().css({
            "border": "#00FF00 solid 2px"
        });
        var old_name = $(this).prev().children().val();//原标签名
        $(this).prev().children().blur(function () {
            $(this).css({
                 "border":"none"
             })
            var groups_name = $(this).val();//编辑后的标签名
            var name = $("#username").text();
            var identify = 5;
            $.ajax({
                type:"get",
                url:"php/search.php",
                data:"name="+name+"&identify="+identify+"&oldname="+old_name+"&newname="+groups_name,
                success:function (response) {
                    if(response == "false"){
                        alert("修改失败！")
                    }else {
                        $("#select").append("<option>"+groups_name+"</option>");
                        $(".newnote li select").append("<option>"+groups_name+"</option>");
                        $(".editnote select").append("<option>"+groups_name+"</option>")
                        console.log(response);
                    }
                },
                error:function (response) {
                    alert("编辑标签名发生错误！"+response);
                }
            })
        });
    });

    //删除标签名
    $(document).on("click",".delete_group",function () {
        var groups_name = $(this).prev().prev().children().val();//原标签名
        var name = $("#username").text();
        var identify = 6;
        var element = $(this);
        $.ajax({
            type:"get",
            url:"php/search.php",
            data:"name="+name+"&identify="+identify+"&groups="+groups_name,
            success:function (response) {
                if(response == "false"){
                    alert("删除失败！");
                }else {
                    console.log(response);
                    element.parent().hide("slide",500);
                }
            },
            error:function (response) {
                alert("删除标签出错！"+response);
            }
        })
    })

    //新建标签名
    $("#new_lable").click(function () {
        $(".group_container").append("<ul class=\"group_tag\">\n" +
            "<li style=\"float: left\"><input type=\"text\" class=\"group_text\" value=\"标签名\" disabled></li>\n" +
            "<li class=\"text edit_group\"><i class=\"fas fa-edit\"></i></li>\n" +
            "<li class=\"text delete_group\"><i class=\"fas fa-trash-alt\"></i></li>\n</ul>")
    });

//    用户注销
    $("#tabs-3 button").click(function () {
        var name = $("#username").text();
        var identify = 1;
        $.ajax({
            type:"get",
            url:"php/search.php",
            data:"name="+name+"identify="+identify,
            success:function (response) {
                 alert(response);
                if(response == "注销成功！"){
                    window.open("login.html");
                }
            },
            error:function (response) {
                alert("发生错误！" + response);
            }
        })
    })

    //保存个人信息
    $("#savemessage").click(function () {
        var date = new Date();
        var name = $("#username").text();
        var nick_kname = $("#nick_name input").val();
        var gender = $("#gender option:selected").text();
        var birthday = $("#birthday input").eq(0).val()+"-"+$("#birthday input").eq(1).val()+"-"+$("#birthday input").eq(2).val();
        var age = date.getFullYear() - $("#birthday input").eq(0).val();
        var identify = 7;
        $.ajax({
            type:"get",
            url:"php/search.php",
            data:"name="+name+"&identify="+identify+"&nick_name="+nick_kname+"&gender="+gender+"&age="+age+"&birthday="+birthday,
            success:function (response) {
                if(response == "false"){
                    alert("个人信息保存失败！");
                }else {
                    $("#tabs").fadeOut(500);
                    $(".name_lable li").eq(1).text(nick_kname);
                    $(".name_lable li").eq(3).text(gender+" "+birthday+" "+age+"岁");
                }
            },
            error:function (response) {
                alert("完善信息操作发生错误！"+response);
            }
        })
    });

    //修改密码
    $("#savesecret").click(function () {
        var name = $("#username").text();
        var identify = 8;
        var pw = /^\d{6}$/;  //密码正则
        var oldsecret = $("#tabs-2 input").eq(0).val();
        var newsecret = $("#tabs-2 input").eq(1).val();
        if(pw.test(oldsecret)&&pw.test(newsecret)){
            if(oldsecret == newsecret){
                alert("新密码不能与新密码一致！");
            }else {
                $.ajax({
                    type:"get",
                    url:"php/search.php",
                    data:"name="+name+"&identify="+identify+"&secret="+newsecret,
                    success:function (response) {
                        if(response == "false"){
                            alert("修改密码失败！");
                        }else {
                            confirm(response);
                            $("#tabs").fadeOut(500);
                        }
                    },
                    error:function (response) {
                        alert("修改密码发生错误！"+response);
                    }
                })
            }
        }else {
            alert("请设置6位数密码")
        }
    })

});
