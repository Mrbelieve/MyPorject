<?php
/**
 * Created by PhpStorm.
 * User: I believe
 * Date: 2019/8/4
 * Time: 15:09
 */
header('content-type: text/html; charset=utf-8');
$name = $_GET["name"];
$identify = $_GET["identify"];
$connect = mysqli_connect("localhost:3306","root","");
if($connect){
    mysqli_select_db($connect,"test");
    $connect->query("set names utf8");//设置数据库查询的编码方式，避免中文乱码
    if($identify == 0){
//        预加载
        $query = mysqli_query($connect,"SELECT nick_name,login_count,gender,age,birthday FROM user WHERE name=".$name);
        if($query){
            $result = mysqli_fetch_assoc($query);
            $jsonresult = json_encode($result);
            echo $jsonresult;
        }else{
            echo "false";
        }

    }
    else if($identify == 1){
//        注销操作
        $query = mysqli_query($connect,"DELETE FROM user WHERE name=".$name);
        if($query){
            echo "注销成功！";
        }else{
            echo "注销失败！";
        }
    }
    else if ($identify == 2){
//        查询所有笔记
        $query = mysqli_query($connect,"SELECT groups,content,create_date FROM user_data WHERE name=$name ORDER BY create_date DESC");
//        $query = mysqli_query($connect,"SELECT groups,content,create_date FROM user_data WHERE name=(SELECT groups,content,create_date FROM user_data WHERE name=.$name)");
        if($query){
            $row = mysqli_num_rows($query);
            for($i = 0;$i < $row;$i++){
                $result = mysqli_fetch_assoc($query);
                $string_result = $result["groups"].",".$result["content"].",".$result["create_date"];
                echo $string_result."***\;][()";
            }
        }else{
            echo "false";
        }
    }
    else if($identify == 3){
//        分组名加载
        $query = mysqli_query($connect,"SELECT groups_name FROM groups WHERE name=".$name);
        if($query){
            $row = mysqli_num_rows($query);
            for ($i = 0;$i < $row;$i++){
                $result = mysqli_fetch_assoc($query);
                $stringresult = $result["groups_name"].",";
                echo $stringresult;
            }
        }else{
            echo "false";
        }
    }
    else if($identify == 4){
        //分组名查找
        $query = mysqli_query($connect,"SELECT groups_name FROM groups WHERE name=".$name);
        if($query){
            $row = mysqli_num_rows($query);
            for ($i = 0;$i < $row;$i++){
                $result = mysqli_fetch_assoc($query);
                $stringresult = $result["groups_name"].",";
                echo $stringresult;
            }
        }else{
            echo "false";
        }
    }
    else if($identify == 5){
        $oldname = $_GET["oldname"];
        $newname = $_GET["newname"];
        if($oldname == "标签名"){
            //新建
            $query = mysqli_query($connect,"INSERT INTO `groups`(`name`,`groups_name`) VALUES($name,'$newname')");
            if($query){
                echo "新建成功!";
            }else{
                echo "false";
            }
        }else{
            //修改标签
            $query = mysqli_query($connect,"UPDATE groups SET groups_name='$newname' WHERE name=$name AND groups_name='$oldname'");
            if($query){
                echo "修改成功!";
            }else{
                echo "false";
            }
        }
    }
    else if($identify == 6){
//        删除标签
        $groups_name = $_GET["groups"];
        $query1 = mysqli_query($connect,"UPDATE groups SET groups_name='默认' WHERE name=$name AND groups_name='$groups_name'");
        $query2 = mysqli_query($connect,"UPDATE user_data SET groups='默认' WHERE name=$name AND groups='$groups_name'");
        if($query1&&$query2){
            echo "删除成功！";
        }else{
            echo "false";
        }
    }
    else if($identify == 7){
        //完善信息操作
        $nick_name = $_GET["nick_name"];
        $gender = $_GET["gender"];
        $age = $_GET["age"];
        $birthday = $_GET["birthday"];
        $query = mysqli_query($connect,"UPDATE `user` SET nick_name='$nick_name',gender='$gender',birthday='$birthday',age='$age' WHERE name=".$name);
        if($query){
            echo "信息保存成功！";
        }else{
            echo "false";
        }
    }
    else if($identify == 8){
        $secret = $_GET["secret"];
        $query = mysqli_query($connect,"UPDATE user SET password=$secret WHERE name=".$name);
        if($query){
            echo "修改成功！";
        }else{
            echo "false";
        }
    }
}else{
    echo "数据库连接失败！";
}

?>